import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ApiserviceService } from '../apiservice.service';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  constructor(private service:ApiserviceService, private router:ActivatedRoute) { }

  errormsg: any;
  successmsg: any;
  getparamid: any;

  ngOnInit(): void {
    this.getparamid = this.router.snapshot.paramMap.get('id');
    this.service.getSingleData(this.getparamid).subscribe((res)=>{
      console.log(res[0].ID)
      this.userForm.patchValue({
        user: res[0].USER_ID,
        pass: res[0].U_PASSWORD,
        email: res[0].U_EMAILID.split("@")[0],
        role: res[0].U_ROLE,
        status: res[0].STATUS,
        updated_on: res[0].LAST_UPDATED_ON.split("T")[0],
        updated_by: res[0].LAST_UPDATED_BY,
      })
      
    })
  }

  userForm = new FormGroup({
    'user' : new FormControl('',Validators.required),
    'pass': new FormControl('',Validators.required),
    'email': new FormControl('',Validators.required),
    'role': new FormControl('',Validators.required),
    'status': new FormControl('',Validators.required),
    'updated_on': new FormControl('',Validators.required),
    'updated_by': new FormControl('',Validators.required)
  })
  userSubmit(){
    // console.log(this.userForm.value);
    if(this.userForm.valid){
      console.log(this.userForm.value)
      this.service.createData(this.userForm.value).subscribe((res) => {
        // console.log(res, 'res==>');
        this.userForm.reset();
        this.successmsg = 'asdfjhasdf';
      })
    }
    else {
      this.errormsg = 'Please input fields correctly!'
    }

  }



  userUpdate() {
    console.log(this.userForm.value)
    if(this.userForm.valid){
      this.service.updateData(this.userForm.value, this.getparamid).subscribe((res)=>{
        console.log('updated successfully')
      })
    }
  }
}
