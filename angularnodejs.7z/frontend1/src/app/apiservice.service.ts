import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { observable, Observable } from 'rxjs';
import { isDelegatedFactoryMetadata } from '@angular/compiler/src/render3/r3_factory';
@Injectable({
  providedIn: 'root'
})
export class ApiserviceService {

  constructor(private _http:HttpClient) { }
  
  //connect to backend 
  apiURL = 'http://localhost:3000/users'

  //get all data
  getAllData():Observable<any>
  {
    return this._http.get(`${this.apiURL}`)
  }
// insert data

  createData(data:any):Observable<any>
  {
    // console.log(data, 'createapi=>')
    return this._http.post(`${this.apiURL}`, data)
  }

  //delete data
  deleteData(id:any):Observable<any>
  {
    let ids = id;
    return this._http.delete(`${this.apiURL}/${ids}`)
  }



   //update data
   updateData(data:any, id:any):Observable<any>
   {
     let ids = id;
    return this._http.put(`${this.apiURL}/${ids}`, data)
   }


   //getSingleData
   getSingleData(id:any):Observable<any>
   {
     let ids = id;
     return this._http.get(`${this.apiURL}/${ids}`)
   }




}



